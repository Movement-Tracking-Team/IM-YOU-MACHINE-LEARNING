# Units and complete preprocessing: Camargo and collected phones

This documents the executed `canonical60_v1` two-sensor experiment. It is different from the original three-sensor, 100 Hz BioMAT reproduction and from the separate UCI HAR phone benchmark.

## Units at each stage

| Quantity | Camargo source/cache | Collected phone CSV | Before final standardization | Actual neural-network input/output |
| --- | --- | --- | --- | --- |
| Accelerometer XYZ | Physical unit not conclusively established: source plotting script says m/s^2, while inspected magnitudes are consistent with g-scale | m/s^2, includes gravity | Dimensionless: divided by each sensor/window's median acceleration-vector magnitude, then rotated | Input: per-channel standardized values, dimensionless |
| Gyroscope XYZ | rad/s according to original `scripts.zip/lib/yLabelSelector.m`; original reproduction retains those values | deg/s | Phone values multiplied by pi/180; both sources then rotated, retaining rad/s | Input: per-channel standardized values, dimensionless |
| Hip/knee/ankle angle | Degrees from original `ik` tables, not `ik_offset` | Not measured by the phones | Target angles stay in degrees; resampled in time only | BioMAT output: degrees, no inverse target scaling |
| Time | `Header` in seconds, nominal 200 Hz | Raw browser event timestamp in ms; normalized/common timestamps in seconds | Common 60 Hz grid | Time determines sampling/windows; timestamps are not input features |

`180 deg/s = pi rad/s`. Degrees/second is rotation speed, not joint angle. Phone `rotation_alpha`, `rotation_beta`, and `rotation_gamma` are preserved rotation-rate fields, not Euler orientation angles.

The acceleration unit discrepancy is unresolved; do not describe Camargo acceleration as confirmed g or confirmed m/s^2. Dividing by the window magnitude removes a fixed positive scale factor, but does not correct sensor bias, saturation, or device-specific filtering. Gravity is not explicitly subtracted.

## A. Camargo preparation inherited from the original reproduction

1. Read the subject ZIPs containing MATLAB `imu`, `ik`, and `conditions` tables. Join matching trials and check their `Header` timestamps agree (absolute tolerance 1e-7 seconds). Reject nonfinite inputs/targets.
2. Use level-ground, ramp and stair trials. The existing preparation separates walking before/after the level-ground turn sequence, and separates ramp/stair ascent and descent. Related transition labels are included in the associated activity; idle and turn portions are not training classes. Treadmill is not included.
3. Inherit the original ground-truth-based exclusion: discard an activity segment if ankle angle is below -100 degrees or hip flexion exceeds 100 degrees. Segments with fewer than four original samples are also excluded. These are training-data rules and are not applicable to phone recordings without angle references.
4. Original feature order: foot, shank, thigh; each contributes Accel_X/Y/Z followed by Gyro_X/Y/Z, giving 18 channels. Targets: `hip_flexion_r`, `knee_angle_r`, `ankle_angle_r`.
5. Resample both inputs and angle targets from nominal 200 Hz to nominal 100 Hz using the original endpoint-inclusive cubic interpolation and half the original number of samples. This inherited conversion does not add an explicit antialias filter, and its endpoint spacing is only nominally 100 Hz.
6. Create 256-sample windows with stride 128. The original preparation pads short segments, but the new two-sensor experiment discards every padded window.

## B. Additional preparation for the retrained two-sensor models

1. Keep only original channels `6:18`: shank then thigh, 12 channels total. Foot data is not used.
2. Keep the first 250 samples of each full 256-sample window, representing a nominal 2.5-second duration.
3. Filter the 12 IMU channels using a fourth-order Butterworth low-pass design, cutoff 20 Hz, source rate 100 Hz, applied forward and backward with `sosfiltfilt`.
4. Resample IMU inputs with `resample_poly(up=3, down=5, axis=1, padtype='line')`, yielding 150 samples at 60 Hz. This includes the resampler's antialias FIR filtering. Resample angle targets with the same 3/5 polyphase conversion and line padding; the separate 20 Hz Butterworth filter is only applied to the IMU inputs.
5. Apply the shared per-window acceleration and orientation normalization described below.
6. Map activity labels to five integers: walking=0, ramp ascent=1, ramp descent=2, stair ascent=3, stair descent=4. The two original level-ground labels merge into walking.
7. Store float32 `x` and `y` in local NPZ files, with activity labels and metadata. These cached inputs have not yet undergone training-population standardization.

The prepared array shapes are `x: [windows, 150, 12]` and `y: [windows, 150, 3]`. Training windows inherit their original 128/100 = nominal 1.28-second start spacing; they do not use the phone inference stride.

## C. Phone acquisition and preparation

1. Browser `DeviceMotionEvent` supplies acceleration including gravity and rotation rate. The collector preserves acceleration XYZ as m/s^2. The gyroscope mapping is `gx=beta`, `gy=gamma`, `gz=alpha`, in deg/s. There is no acquisition-stage smoothing, gravity removal, or unit conversion in our collector; browser/OS internal sensor processing is outside our control.
2. Phone events are transported in JSON packets, recorded in JSONL journals, and exported into per-phone and combined CSVs. A browser event timestamp is not an independently measured hardware timestamp for each sensor.
3. The receiver establishes common time using `common_timestamp = phone_timestamp - estimated_clock_offset`. `session_time_s = common_timestamp - recording_start`. Clock synchronization is estimated rather than physically verified.
4. Use phone 2 as shank and phone 1 as thigh. Both were confirmed on the right leg, front mounted, screens out, top edges up, with an upright still period at the beginning. This confirmation documents placement; the code does not use the initial still period to calculate an anatomical calibration.
5. Read `common_timestamp, ax, ay, az, gx, gy, gz`. Require at least 150 finite rows, strictly increasing timestamps, no gap greater than 50 ms, and observed mean sample rate within 55-65 Hz. Validate the CSV unit labels.
6. Convert `gx, gy, gz` from deg/s to rad/s using multiplication by pi/180. Leave acceleration in m/s^2 until the shared magnitude normalization.
7. Keep the overlapping time range of the two recordings. Linearly interpolate each sensor channel onto the same uniform 60 Hz grid. No interpolation is used outside their shared range.
8. Concatenate shank then thigh. Apply a fourth-order Butterworth low-pass design at 20 Hz, with rate 60 Hz, using forward/backward filtering over the entire aligned recording.
9. Build 150-sample windows, advancing 30 samples (0.5 seconds). A window contains 2.5 seconds' worth of samples; first-to-last timestamp difference is 149/60 = 2.4833 seconds. Neighboring windows overlap by 80%.
10. Apply exactly the same per-window normalization function used for Camargo training.

The phone and training resampling/filtering paths are not numerically identical: Camargo uses window-level filtering plus 100-to-60 Hz polyphase resampling; phones use interpolation near their native 60 Hz rate and filtering across the whole recording. Their bandwidth and target rate are matched, but browser processing and edge effects remain differences.

## D. Shared per-window normalization

This is done independently for the shank and thigh, using all 150 samples and no activity/angle labels:

1. Compute `s = median_t(sqrt(ax^2 + ay^2 + az^2))`. Divide all three accelerometer channels by `s`. Acceleration is now dimensionless; this is not division by a fixed 9.80665 and is not removal of gravity.
2. Normalize the mean acceleration vector to obtain a reference axis `v`. It approximates a gravity direction but is affected by dynamic acceleration; it is not guaranteed to be anatomical vertical.
3. Remove each gyroscope vector's component parallel to `v` for the purpose of estimating the second axis. Compute the second-moment matrix of these transverse vectors, and use its leading eigenvector as the principal rotation axis. This matrix is not additionally mean-centered.
4. Make that axis perpendicular to `v`, normalize it, and choose its sign so the largest-absolute gyroscope projection is positive. The third axis is a cross product, making a proper orthonormal basis.
5. Rotate the normalized acceleration and the full, unscaled rad/s gyroscope into that basis. The projected transverse gyro is used only to construct the frame, not substituted for the full gyro input.

The resulting order is:

```text
[shank_acc_basis1, shank_acc_basis2, shank_acc_basis3,
 shank_gyro_basis1, shank_gyro_basis2, shank_gyro_basis3,
 thigh_acc_basis1, thigh_acc_basis2, thigh_acc_basis3,
 thigh_gyro_basis1, thigh_gyro_basis2, thigh_gyro_basis3]
```

These are signal-derived axes, not the original phone XYZ or proven anatomical axes. Fixed mounting rotations cancel under this transformation for nondegenerate windows; the implemented rotation/acceleration-scale invariance test passed. Absolute segment orientation is removed, and frame/sign choices may change between windows. This transform does not establish accurate physical joint angles.

## E. Training-only standardization and network inputs

After per-window normalization, calculate a mean and standard deviation for each of the 12 channels over the training windows and time samples. Very small standard deviations (<1e-8) are replaced by 1.

```text
model_input[channel] = (normalized_channel - training_mean[channel])
                       / training_standard_deviation[channel]
```

Fit the scaler separately within each subject-validation fold; fit the final scaler on AB06-AB21 only. Never fit or update it using the test participants or the phone recordings. Each checkpoint stores its scaler, and inference loads that checkpoint's values.

Both networks receive float32 tensors shaped `[batch, 150, 12]`. The classifier internally transposes to `[batch, 12, 150]` for convolution. All standardized input channels are dimensionless. Angle targets are not standardized.

Five participant-disjoint validation folds use AB06-AB21. Final test participants AB23/24/25 are excluded from training and selection in this run, although they were evaluated in earlier experiments. No phone measurements or phone activity labels are used for model fitting or epoch selection.

## F. Phone quality gate and outputs

For each phone, a window must have at least 75% of samples with filtered gyro magnitude greater than 0.25 rad/s (about 14.3 deg/s). The leading transverse-gyro eigenvalue must account for at least 60% of the matrix trace. Both phones must pass. This is a fixed motion/frame-quality gate, not a trained standing class or validated unknown-activity detector.

The implementation computes and saves raw model outputs for all windows with a `usable` mask, but reports activity and angle results only from windows passing the gate. Do not ignore that mask when reading the NPZ files.

- CNN output: five logits, converted with softmax into uncalibrated class scores; the largest selects a candidate class. Scores are not validated probabilities of correctness.
- BioMAT output: `[batch, 150, 3]` values in degrees, in hip/knee/ankle order. These are model estimates, not angles obtained by integrating the phone gyroscope.
- Overlapping accepted angle predictions are averaged at each shared timestamp. Unsupported times are blank/NaN in the CSV.
- Angle CSV retains original Camargo/OpenSim signs. The plot negates the knee output only, to show knee flexion as positive. Hip and ankle signs are unchanged.

## G. Implication for live streaming

The current phone script is offline. Forward/backward filtering over the whole recording can use future samples; the window normalization and BioMAT also use the complete window. The saved results therefore do not demonstrate a causal, zero-delay live pipeline. A streaming implementation must specify buffering and filtering, preserve or validate the preprocessing behavior, and measure end-to-end delay. Simply emitting the existing pipeline every half-second is not proof of equivalence to the offline outputs.

## Code references

- [Original Camargo preparation](../biomat/prepare.py)
- [Two-sensor preparation, normalization, fitting, and saved scalers](../biomat/two_sensor.py)
- [Phone reading, conversion, resampling, gate, and inference](../biomat/two_sensor_phone.py)
- [Browser sensor fields and timestamp normalization](../phone-imu/public/shared.js)
- [Receiver common-clock calculation](../phone-imu/lib/receiver.mjs)
- Original unit labels: `Camargo et al. Dataset/scripts.zip`, member `lib/yLabelSelector.m`.
