"""Standalone offline inference for the separately trained two-sensor BioMAT."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.signal import butter, sosfiltfilt
import torch
from model import BioMAT

BASE = Path(__file__).resolve().parent
HZ, LENGTH = 60, 150
SITES = ['shank', 'thigh']
TARGETS = ['hip_flexion_r', 'knee_angle_r', 'ankle_angle_r']
PREPROCESS = 'canonical60_v1: 20Hz lowpass; 150 samples; median acceleration norm; mean-acceleration + transverse-gyro PCA basis; peak-projection sign'


def canonicalize(x):
    """Same deterministic, label-free rotation/acceleration-scale normalization per window.

This frame is signal-derived, NOT an anatomical calibration. Its sign may change
between windows. All predictions and validation use this same representation.
"""
    x = np.asarray(x, dtype=np.float64)
    if x.ndim != 3 or x.shape[1:] != (LENGTH, 12) or not np.isfinite(x).all():
        raise ValueError('Expected finite N x 150 x 12 signals')
    out = np.empty_like(x)
    quality = []
    for site in range(2):
        a, w = x[:, :, site*6:site*6+3], x[:, :, site*6+3:site*6+6]
        scale = np.median(np.linalg.norm(a, axis=2), axis=1)
        if np.any(scale < 1e-8):
            raise ValueError('Cannot normalize zero acceleration')
        a = a / scale[:, None, None]
        vertical = a.mean(1)
        strength = np.linalg.norm(vertical, axis=1)
        if np.any(strength < 1e-6):
            raise ValueError('Mean acceleration does not establish a stable reference')
        vertical /= strength[:, None]
        transverse = w - np.einsum('nti,ni->nt', w, vertical)[:, :, None] * vertical[:, None, :]
        cov = np.einsum('nti,ntj->nij', transverse, transverse) / LENGTH
        eigenvalues, vectors = np.linalg.eigh(cov)
        lateral = vectors[:, :, -1]
        lateral -= np.sum(lateral * vertical, axis=1)[:, None] * vertical
        lateral_norm = np.linalg.norm(lateral, axis=1)
        if np.any(lateral_norm < 1e-8):
            raise ValueError('No transverse rotation reference')
        lateral /= lateral_norm[:, None]
        projection = np.einsum('nti,ni->nt', transverse, lateral)
        peak = projection[np.arange(len(x)), np.abs(projection).argmax(1)]
        lateral *= np.where(peak < 0, -1., 1.)[:, None]
        forward = np.cross(vertical, lateral)
        basis = np.stack([lateral, forward, vertical], axis=2)
        out[:, :, site*6:site*6+3] = np.einsum('nti,nij->ntj', a, basis)
        out[:, :, site*6+3:site*6+6] = np.einsum('nti,nij->ntj', w, basis)
        quality.append({'median_acceleration_norm': scale,
                        'transverse_gyro_rms': np.sqrt(np.maximum(eigenvalues[:, -1], 0)),
                        'principal_axis_fraction': eigenvalues[:, -1] / np.maximum(eigenvalues.sum(1), 1e-12)})
    return out.astype(np.float32), quality

def read_phone(path):
    df = pd.read_csv(path)
    columns = ['common_timestamp', 'ax', 'ay', 'az', 'gx', 'gy', 'gz']
    values = df[columns].to_numpy(dtype=np.float64)
    if len(values) < LENGTH or not np.isfinite(values).all():
        raise ValueError('Missing/invalid phone samples')
    if set(df.accel_units) not in ({'m/s^2'}, {'g'}) or set(df.gyro_units) not in ({'deg/s'}, {'rad/s'}):
        raise ValueError('Unexpected phone units')
    t, x = values[:, 0], values[:, 1:]
    dt = np.diff(t)
    rate = (len(t)-1)/(t[-1]-t[0])
    if (dt <= 0).any() or dt.max() > .05 or not 55 <= rate <= 65:
        raise ValueError('This adapter requires a continuous approximately 60 Hz recording')
    if set(df.accel_units) == {'g'}:
        x[:, :3] *= 9.80665
    if set(df.gyro_units) == {'deg/s'}:
        x[:, 3:] = np.deg2rad(x[:, 3:])
    return t, x, rate, df

def prepare_phone(session):
    # Phone 1 is thigh; phone 2 is shank. Model ordering is shank then thigh.
    loaded = [read_phone(session / name) for name in ['phone_2.csv', 'phone_1.csv']]
    origin = float(json.loads((session/'metadata.json').read_text())['start'])
    start, stop = max(a[0][0] for a in loaded), min(a[0][-1] for a in loaded)
    timeline = start + np.arange(int(np.floor((stop-start)*HZ))+1)/HZ
    if len(timeline) < LENGTH:
        raise ValueError('Insufficient synchronized overlap')
    x = np.concatenate([np.column_stack([np.interp(timeline,t,v[:,j]) for j in range(6)])
                        for t,v,_,_ in loaded],axis=1)
    x = sosfiltfilt(butter(4,20,fs=HZ,output='sos'),x,axis=0)
    starts = np.arange(0, len(x)-LENGTH+1, 30)
    windows = np.stack([x[s:s+LENGTH] for s in starts])
    canonical, quality = canonicalize(windows)
    # Fixed acquisition/low-motion gate, not a learned standing class or OOD detector.
    moving = np.ones(len(windows), dtype=bool)
    for site in range(2):
        gyro = windows[:,:,site*6+3:site*6+6]
        fraction = (np.linalg.norm(gyro,axis=2) > .25).mean(1)
        moving &= fraction >= .75
        moving &= quality[site]['principal_axis_fraction'] >= .6
    info = {'rates_hz': {site: v[2] for site,v in zip(SITES,loaded)},
            'input_sha256': {name:hashlib.sha256((session/name).read_bytes()).hexdigest()
                             for name in ['phone_1.csv','phone_2.csv']},
            'session_origin_host_s':origin, 'gating': 'Both phones >=75% samples angular speed >0.25 rad/s; transverse gyro principal-axis fraction >=0.6',
            'quality': [{key:val.tolist() for key,val in q.items()} for q in quality]}
    return canonical, starts, timeline-origin, moving, info

@torch.inference_mode()
def predict(model, x, mean, scale, device, task):
    model.eval()
    out = []
    for start in range(0, len(x), 64):
        batch = torch.from_numpy((x[start:start+64] - mean) / scale).to(device)
        value = model(batch)
        if task == 'classifier':
            value = value.softmax(-1)
        out.append(value.cpu().numpy())
    return np.concatenate(out)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session', type=Path, default=BASE / 'example_original')
    parser.add_argument('--output', type=Path, default=BASE / 'output')
    parser.add_argument('--verify', action='store_true', help='Compare against bundled example reference predictions')
    args = parser.parse_args()
    torch.set_num_threads(4)
    saved = torch.load(BASE / 'model.pt', map_location='cpu', weights_only=True)
    if saved['sites'] != SITES or saved['preprocess'] != PREPROCESS or saved['sample_rate'] != HZ or saved['window_length'] != LENGTH or saved['targets'] != TARGETS:
        raise ValueError('Checkpoint metadata does not match this adapter')
    model = BioMAT(seq_len=LENGTH, features=12)
    model.load_state_dict(saved['state_dict'], strict=True)
    x, starts, timeline, usable, _ = prepare_phone(args.session.resolve())
    predictions = predict(model, x, saved['mean'].numpy(), saved['scale'].numpy(), 'cpu', 'regressor')
    if not np.isfinite(predictions).all():
        raise ValueError('Nonfinite predictions')
    args.output.mkdir(parents=True, exist_ok=True)
    np.savez(args.output / 'regressor_window_predictions.npz', predictions=predictions,
             usable=usable, start_session_s=timeline[starts])
    sums = np.zeros((len(timeline), 3))
    counts = np.zeros(len(timeline), dtype=int)
    for k, start in enumerate(starts):
        if usable[k]:
            sums[start:start+LENGTH] += predictions[k]
            counts[start:start+LENGTH] += 1
    avg = np.full_like(sums, np.nan)
    np.divide(sums, counts[:, None], out=avg, where=counts[:, None] > 0)
    table = pd.DataFrame({'session_time_s': timeline, 'contributing_windows': counts})
    for j, name in enumerate(TARGETS):
        table[name + '_degrees_unvalidated'] = avg[:, j]
    table.to_csv(args.output / 'joint_angles_experimental.csv', index=False)
    report = {'windows': len(x), 'accepted_windows': int(usable.sum()), 'output_units': 'degrees',
              'checkpoint_sha256': hashlib.sha256((BASE / 'model.pt').read_bytes()).hexdigest()}
    if args.verify:
        with np.load(BASE / 'reference/regressor_window_predictions.npz') as reference:
            np.testing.assert_array_equal(usable, reference['usable'])
            np.testing.assert_allclose(timeline[starts], reference['start_session_s'], rtol=0, atol=1e-9)
            np.testing.assert_allclose(predictions, reference['predictions'], rtol=0, atol=5e-4)
            report['maximum_window_error_degrees'] = float(np.max(np.abs(predictions - reference['predictions'])))
        expected = pd.read_csv(BASE / 'reference/joint_angles_experimental.csv')
        np.testing.assert_array_equal(counts, expected['contributing_windows'])
        np.testing.assert_allclose(table.to_numpy(), expected.to_numpy(), rtol=0, atol=5e-4, equal_nan=True)
        report['verification'] = 'passed (absolute angle tolerance 0.0005 degrees)'
    (args.output / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()

