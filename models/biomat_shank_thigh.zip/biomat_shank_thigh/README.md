# Two-sensor BioMAT checkpoint and reproducible phone inference

This is the separately trained right-shank/right-thigh BioMAT model, canonical60_v1,
epoch 21. The model was trained from scratch on Camargo participants AB06-AB21.
It does not require a foot sensor. The activity classifier is not included.

## Run the bundled example

Use Python 3.11 in a virtual environment. A GPU is not required.

```sh
python -m pip install -r requirements.txt
python predict.py --verify
python predict.py --session example_g_rad_s --output output_g_rad_s --verify
```

The runner loads model.pt with weights_only=True, applies the saved training mean
and standard deviation, and runs model.eval() on CPU. The reference is the earlier
saved phone inference output, not predictions generated during packaging.
Verification compares every window, its usability mask, timestamps, and the
overlap-averaged angle CSV. Cross-platform floating-point differences are allowed
up to 0.0005 degrees; this numerical tolerance is not a measure of model accuracy.

The input shape is [batch, 150, 12] at 60 Hz, in SHANK THEN THIGH order.
Each sensor contributes acceleration XYZ followed by gyroscope XYZ in the
signal-derived basis. Output shape is [batch, 150, 3], hip/knee/ankle in DEGREES.
The checkpoint contains state_dict, mean, scale, and preprocessing metadata.

## Input files and units

phone_1.csv is the right thigh; phone_2.csv is the right shank. The CSV columns
common_timestamp, ax, ay, az, gx, gy, gz, accel_units, gyro_units are required.
metadata.json supplies recording start time in the same clock as common_timestamp.
The loader accepts acceleration in m/s^2 or g and gyro in deg/s or rad/s, using
the explicit unit columns. It converts g to m/s^2 with 9.80665 and converts deg/s
to rad/s only when necessary. It then applies the original normalization.
Both original and converted versions of the same recording are included.

There are 31 windows, of which 20 pass the original motion/frame gate. The NPZ
retains all windows; use its usable mask. The CSV averages accepted overlapping
predictions and leaves unsupported times blank. It retains original angle signs;
the earlier plot displayed knee flexion by negating the raw knee output.

## Reproduction scope

This bundle reproduces inference on the included phone recording. It does not
retrain the network or independently reproduce the complete Camargo test study:
those require the Camargo data, subject splits, and full training pipeline.
training_protocol.json and training_results.md identify that experiment.
The lab test errors do not establish phone joint-angle accuracy. Phone ground
truth is absent. This preprocessing is offline and uses future samples.

The exact normalization and phone-alignment functions were extracted from the
local experiment; the portable reader adds explicit g/rad/s support. model.py
is copied unchanged from the local BioMAT port, which identifies upstream
MohsenSharifi1991/BioMAT commit 0ca003db. preprocessing_reference.md is the
original detailed reference; its repository-relative code links refer to the
original repository layout. predict.py contains the standalone implementation.

Tested packaging environment: Python 3.11, torch 2.11.0+cu128 (CPU inference),
numpy 2.4.6, pandas 3.1.1, scipy 1.17.1. requirements.txt uses the portable torch
version without a CUDA-specific local version suffix.
