# Camargo thigh/shank models at 60 Hz

Both models are trained from scratch using only right shank and right thigh IMU data. Foot data, phone recordings and phone labels do not enter training or model selection.

Final Camargo test: **92.72% classification accuracy**, macro-F1 **0.9426**; 1910 full windows from AB23/AB24/AB25.

| Joint | Test RMSE (degrees) | Test MAE (degrees) | Mean CV RMSE (degrees) |
| --- | ---: | ---: | ---: |
| Hip | 6.80 | 4.88 | 7.34 |
| Knee | 6.38 | 4.48 | 6.98 |
| Ankle | 5.57 | 4.05 | 6.13 |

Five-fold mean classification accuracy: 94.28%. Final BioMAT training duration: 21 epochs, chosen before final testing.

| Activity | Precision | Recall | F1 | Windows |
| --- | ---: | ---: | ---: | ---: |
| walking | 0.760 | 1.000 | 0.864 | 425 |
| ramp_ascent | 1.000 | 0.904 | 0.950 | 521 |
| ramp_descent | 0.998 | 0.845 | 0.915 | 560 |
| stair_ascent | 0.991 | 1.000 | 0.995 | 220 |
| stair_descent | 0.989 | 0.989 | 0.989 | 184 |

| Subject | Classifier accuracy | Hip RMSE | Knee RMSE | Ankle RMSE |
| --- | ---: | ---: | ---: | ---: |
| AB23 | 99.66% | 5.06 | 6.05 | 5.21 |
| AB24 | 98.75% | 5.52 | 7.11 | 5.52 |
| AB25 | 82.87% | 8.60 | 6.06 | 5.87 |

## Protocol

Input order: shank then thigh, each with acceleration XYZ and angular velocity XYZ. Full Camargo windows only; first 250 samples at nominal 100 Hz are filtered at 20 Hz and resampled with a polyphase antialias filter to 150 samples at 60 Hz (2.5 seconds). Angle targets are resampled on the same grid. The earlier window preparation and ground-truth-based segment exclusions are inherited. This is a separate two-sensor experiment, not an exact BioMAT paper reproduction.

Both sources use the same per-window signal-derived coordinate frame: normalize acceleration by its median vector magnitude; use mean acceleration for one axis and transverse gyroscope PCA for a perpendicular axis; choose its sign from the largest absolute projection. This removes fixed mounting rotation and acceleration units, but also removes absolute segment orientation. It is not an anatomical calibration. The original plotting script labels acceleration as m/s^2 despite the stored magnitudes being around one at rest; this experiment avoids relying on that label. Gyroscope units are rad/s according to scripts.zip/lib/yLabelSelector.m.

Classification: MovementCNN with 12 inputs, 5 classes, three convolution blocks, 30 fixed epochs, AdamW lr 0.001 and weight decay 0.0001, batch 128, class-weighted cross entropy. Regression: BioMAT with 12 inputs, sequence length 150, 4 encoder layers, embedding 256, 16 heads, feedforward 128, dropout 0.5, three original angle heads; Adam lr 0.001, weight decay 0.001, batch 50.

Five subject folds within AB06-AB21, training-only standardization. Regression uses up to 50 epochs and patience 8; each fold retains the best subject-mean joint RMSE checkpoint. Final regression trains for the ceiling of the median selected epoch on all 16 development participants. AB23/24/25 are evaluated after selection, but were used in earlier experiments; these are not a fresh study cohort. The three extra subjects remain unused.

## Interpretation

These errors measure the Camargo lab data, not phone accuracy. Hip and ankle estimates can exploit gait correlations without measuring the pelvis or foot, but may fail on unusual motion. The classifier covers curated walking/ramp/stair windows only, not standing, running, or unknown activities. Windows overlap and are not independent observations. Canonicalization is noncausal and uses a complete window. No confidence interval or phone joint-angle error is available.

All final metrics were independently recomputed from saved predictions. Checkpoints and protocol: `Camargo et al. Dataset/two_sensor/canonical60_v1/`. Final models: `final/classifier/model.pt` and `final/regressor/model.pt`.

[Test confusion matrix and angle errors](two_sensor_results.png)
